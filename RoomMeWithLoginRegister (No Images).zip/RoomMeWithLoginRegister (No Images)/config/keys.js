dbPassword = 'mongodb+srv://jsales2:RoomMe1234@cluster0.ctl0m.mongodb.net/room-me?retryWrites=true&w=majority'

module.exports = {
    mongoURI: dbPassword
};
